﻿namespace _05MiniEditor
{
    partial class fmEditorTextos
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gbAlineacion = new System.Windows.Forms.GroupBox();
            this.rbDerecha = new System.Windows.Forms.RadioButton();
            this.rbCentrada = new System.Windows.Forms.RadioButton();
            this.rbIzquierda = new System.Windows.Forms.RadioButton();
            this.gbEstilo = new System.Windows.Forms.GroupBox();
            this.cbTachado = new System.Windows.Forms.CheckBox();
            this.cbCursiva = new System.Windows.Forms.CheckBox();
            this.cbSubrayado = new System.Windows.Forms.CheckBox();
            this.cbNegrita = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbColores = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btGuardar = new System.Windows.Forms.Button();
            this.btAbrir = new System.Windows.Forms.Button();
            this.cbTamanio = new System.Windows.Forms.ComboBox();
            this.cbFuente = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.archivoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.nuevoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.guardarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ediciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itCortar = new System.Windows.Forms.ToolStripMenuItem();
            this.itCopiar = new System.Windows.Forms.ToolStripMenuItem();
            this.itPegar = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.itVaciar = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.itDeshacer = new System.Windows.Forms.ToolStripMenuItem();
            this.itRehacer = new System.Windows.Forms.ToolStripMenuItem();
            this.formatoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.alineaciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itDere = new System.Windows.Forms.ToolStripMenuItem();
            this.itCent = new System.Windows.Forms.ToolStripMenuItem();
            this.itIzq = new System.Windows.Forms.ToolStripMenuItem();
            this.estiloToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itNegrita = new System.Windows.Forms.ToolStripMenuItem();
            this.itCursiva = new System.Windows.Forms.ToolStripMenuItem();
            this.itSubrayado = new System.Windows.Forms.ToolStripMenuItem();
            this.itTachado = new System.Windows.Forms.ToolStripMenuItem();
            this.itColores = new System.Windows.Forms.ToolStripMenuItem();
            this.itRojo = new System.Windows.Forms.ToolStripMenuItem();
            this.itVerde = new System.Windows.Forms.ToolStripMenuItem();
            this.itAzul = new System.Windows.Forms.ToolStripMenuItem();
            this.itGris = new System.Windows.Forms.ToolStripMenuItem();
            this.itAmarillo = new System.Windows.Forms.ToolStripMenuItem();
            this.itNegro = new System.Windows.Forms.ToolStripMenuItem();
            this.itNaranja = new System.Windows.Forms.ToolStripMenuItem();
            this.ayudaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.acercaDeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rtbEditor = new System.Windows.Forms.RichTextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.edicionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formatoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ayudaToolStripMenuItem = new System.Windows.Forms.ToolStripSeparator();
            this.vaciarPortapapelesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.totiColor = new System.Windows.Forms.ToolTip(this.components);
            this.panel1.SuspendLayout();
            this.gbAlineacion.SuspendLayout();
            this.gbEstilo.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.gbAlineacion);
            this.panel1.Controls.Add(this.gbEstilo);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.lbColores);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.tbNombre);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btGuardar);
            this.panel1.Controls.Add(this.btAbrir);
            this.panel1.Controls.Add(this.cbTamanio);
            this.panel1.Controls.Add(this.cbFuente);
            this.panel1.Controls.Add(this.menuStrip1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1003, 257);
            this.panel1.TabIndex = 10;
            // 
            // gbAlineacion
            // 
            this.gbAlineacion.Controls.Add(this.rbDerecha);
            this.gbAlineacion.Controls.Add(this.rbCentrada);
            this.gbAlineacion.Controls.Add(this.rbIzquierda);
            this.gbAlineacion.Location = new System.Drawing.Point(705, 50);
            this.gbAlineacion.Name = "gbAlineacion";
            this.gbAlineacion.Size = new System.Drawing.Size(251, 157);
            this.gbAlineacion.TabIndex = 21;
            this.gbAlineacion.TabStop = false;
            this.gbAlineacion.Text = "Alineación";
            // 
            // rbDerecha
            // 
            this.rbDerecha.AutoSize = true;
            this.rbDerecha.Location = new System.Drawing.Point(78, 114);
            this.rbDerecha.Name = "rbDerecha";
            this.rbDerecha.Size = new System.Drawing.Size(83, 21);
            this.rbDerecha.TabIndex = 2;
            this.rbDerecha.Text = "Derecha";
            this.rbDerecha.UseVisualStyleBackColor = true;
            this.rbDerecha.CheckedChanged += new System.EventHandler(this.rbIzquierda_CheckedChanged);
            // 
            // rbCentrada
            // 
            this.rbCentrada.AutoSize = true;
            this.rbCentrada.Location = new System.Drawing.Point(78, 74);
            this.rbCentrada.Name = "rbCentrada";
            this.rbCentrada.Size = new System.Drawing.Size(87, 21);
            this.rbCentrada.TabIndex = 1;
            this.rbCentrada.Text = "Centrada";
            this.rbCentrada.UseVisualStyleBackColor = true;
            this.rbCentrada.CheckedChanged += new System.EventHandler(this.rbIzquierda_CheckedChanged);
            // 
            // rbIzquierda
            // 
            this.rbIzquierda.AutoSize = true;
            this.rbIzquierda.Checked = true;
            this.rbIzquierda.Location = new System.Drawing.Point(78, 35);
            this.rbIzquierda.Name = "rbIzquierda";
            this.rbIzquierda.Size = new System.Drawing.Size(87, 21);
            this.rbIzquierda.TabIndex = 0;
            this.rbIzquierda.TabStop = true;
            this.rbIzquierda.Text = "Izquierda";
            this.rbIzquierda.UseVisualStyleBackColor = true;
            this.rbIzquierda.CheckedChanged += new System.EventHandler(this.rbIzquierda_CheckedChanged);
            // 
            // gbEstilo
            // 
            this.gbEstilo.Controls.Add(this.cbTachado);
            this.gbEstilo.Controls.Add(this.cbCursiva);
            this.gbEstilo.Controls.Add(this.cbSubrayado);
            this.gbEstilo.Controls.Add(this.cbNegrita);
            this.gbEstilo.Location = new System.Drawing.Point(502, 50);
            this.gbEstilo.Name = "gbEstilo";
            this.gbEstilo.Size = new System.Drawing.Size(132, 171);
            this.gbEstilo.TabIndex = 20;
            this.gbEstilo.TabStop = false;
            this.gbEstilo.Text = "Estilo";
            this.totiColor.SetToolTip(this.gbEstilo, "Elige un estilo para la fuente");
            // 
            // cbTachado
            // 
            this.cbTachado.AutoSize = true;
            this.cbTachado.Location = new System.Drawing.Point(27, 126);
            this.cbTachado.Name = "cbTachado";
            this.cbTachado.Size = new System.Drawing.Size(86, 21);
            this.cbTachado.TabIndex = 3;
            this.cbTachado.Text = "Tachado";
            this.cbTachado.UseVisualStyleBackColor = true;
            this.cbTachado.CheckedChanged += new System.EventHandler(this.cbNegrita_CheckedChanged);
            // 
            // cbCursiva
            // 
            this.cbCursiva.AutoSize = true;
            this.cbCursiva.Location = new System.Drawing.Point(27, 90);
            this.cbCursiva.Name = "cbCursiva";
            this.cbCursiva.Size = new System.Drawing.Size(77, 21);
            this.cbCursiva.TabIndex = 2;
            this.cbCursiva.Text = "Cursiva";
            this.cbCursiva.UseVisualStyleBackColor = true;
            this.cbCursiva.CheckedChanged += new System.EventHandler(this.cbNegrita_CheckedChanged);
            // 
            // cbSubrayado
            // 
            this.cbSubrayado.AutoSize = true;
            this.cbSubrayado.Location = new System.Drawing.Point(27, 51);
            this.cbSubrayado.Name = "cbSubrayado";
            this.cbSubrayado.Size = new System.Drawing.Size(99, 21);
            this.cbSubrayado.TabIndex = 1;
            this.cbSubrayado.Text = "Subrayado";
            this.cbSubrayado.UseVisualStyleBackColor = true;
            this.cbSubrayado.CheckedChanged += new System.EventHandler(this.cbNegrita_CheckedChanged);
            // 
            // cbNegrita
            // 
            this.cbNegrita.AutoSize = true;
            this.cbNegrita.Location = new System.Drawing.Point(28, 21);
            this.cbNegrita.Name = "cbNegrita";
            this.cbNegrita.Size = new System.Drawing.Size(76, 21);
            this.cbNegrita.TabIndex = 0;
            this.cbNegrita.Text = "Negrita";
            this.cbNegrita.UseVisualStyleBackColor = true;
            this.cbNegrita.CheckedChanged += new System.EventHandler(this.cbNegrita_CheckedChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(275, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 17);
            this.label4.TabIndex = 19;
            this.label4.Text = "Color de la fuente";
            // 
            // lbColores
            // 
            this.lbColores.FormattingEnabled = true;
            this.lbColores.ItemHeight = 16;
            this.lbColores.Items.AddRange(new object[] {
            "Rojo",
            "Verde",
            "Azul",
            "Gris",
            "Amarillo",
            "Naranja",
            "Negro"});
            this.lbColores.Location = new System.Drawing.Point(275, 121);
            this.lbColores.Name = "lbColores";
            this.lbColores.Size = new System.Drawing.Size(120, 116);
            this.lbColores.TabIndex = 18;
            this.totiColor.SetToolTip(this.lbColores, "Colorea la Fuente");
            this.lbColores.SelectedIndexChanged += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 204);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 17);
            this.label3.TabIndex = 17;
            this.label3.Text = "Nombre";
            // 
            // tbNombre
            // 
            this.tbNombre.Location = new System.Drawing.Point(42, 227);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(100, 22);
            this.tbNombre.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(275, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 17);
            this.label2.TabIndex = 15;
            this.label2.Text = "Tamaño";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 17);
            this.label1.TabIndex = 14;
            this.label1.Text = "Fuente";
            // 
            // btGuardar
            // 
            this.btGuardar.Location = new System.Drawing.Point(45, 151);
            this.btGuardar.Name = "btGuardar";
            this.btGuardar.Size = new System.Drawing.Size(75, 23);
            this.btGuardar.TabIndex = 13;
            this.btGuardar.Text = "Guardar";
            this.btGuardar.UseVisualStyleBackColor = true;
            this.btGuardar.Click += new System.EventHandler(this.btGuardar_Click);
            // 
            // btAbrir
            // 
            this.btAbrir.Location = new System.Drawing.Point(45, 122);
            this.btAbrir.Name = "btAbrir";
            this.btAbrir.Size = new System.Drawing.Size(75, 23);
            this.btAbrir.TabIndex = 12;
            this.btAbrir.Text = "Abrir";
            this.totiColor.SetToolTip(this.btAbrir, "Abre un archivo con su nombre");
            this.btAbrir.UseVisualStyleBackColor = true;
            this.btAbrir.Click += new System.EventHandler(this.btAbrir_Click);
            // 
            // cbTamanio
            // 
            this.cbTamanio.FormattingEnabled = true;
            this.cbTamanio.Items.AddRange(new object[] {
            "8",
            "10",
            "12",
            "14",
            "16",
            "18",
            "24",
            "26",
            "28",
            "32"});
            this.cbTamanio.Location = new System.Drawing.Point(275, 63);
            this.cbTamanio.MaxLength = 2;
            this.cbTamanio.Name = "cbTamanio";
            this.cbTamanio.Size = new System.Drawing.Size(67, 24);
            this.cbTamanio.TabIndex = 11;
            this.totiColor.SetToolTip(this.cbTamanio, "Pon un tamaño de letra");
            this.cbTamanio.TextChanged += new System.EventHandler(this.cbTamanio_TextChanged);
            this.cbTamanio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbTamanio_KeyPress);
            // 
            // cbFuente
            // 
            this.cbFuente.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFuente.FormattingEnabled = true;
            this.cbFuente.Location = new System.Drawing.Point(42, 63);
            this.cbFuente.Name = "cbFuente";
            this.cbFuente.Size = new System.Drawing.Size(155, 24);
            this.cbFuente.TabIndex = 10;
            this.totiColor.SetToolTip(this.cbFuente, "Cambia el tipo de fuente");
            this.cbFuente.TextChanged += new System.EventHandler(this.cbFuente_TextChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoToolStripMenuItem1,
            this.ediciónToolStripMenuItem,
            this.formatoToolStripMenuItem1,
            this.ayudaToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1003, 28);
            this.menuStrip1.TabIndex = 22;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // archivoToolStripMenuItem1
            // 
            this.archivoToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevoToolStripMenuItem,
            this.toolStripMenuItem1,
            this.toolStripMenuItem3,
            this.guardarToolStripMenuItem,
            this.toolStripMenuItem2,
            this.salirToolStripMenuItem});
            this.archivoToolStripMenuItem1.Name = "archivoToolStripMenuItem1";
            this.archivoToolStripMenuItem1.Size = new System.Drawing.Size(71, 24);
            this.archivoToolStripMenuItem1.Text = "A&rchivo";
            // 
            // nuevoToolStripMenuItem
            // 
            this.nuevoToolStripMenuItem.Name = "nuevoToolStripMenuItem";
            this.nuevoToolStripMenuItem.Size = new System.Drawing.Size(137, 26);
            this.nuevoToolStripMenuItem.Text = "Nuevo";
            this.nuevoToolStripMenuItem.Click += new System.EventHandler(this.nuevoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(134, 6);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(137, 26);
            this.toolStripMenuItem3.Text = "Abrir";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.btAbrir_Click);
            // 
            // guardarToolStripMenuItem
            // 
            this.guardarToolStripMenuItem.Name = "guardarToolStripMenuItem";
            this.guardarToolStripMenuItem.Size = new System.Drawing.Size(137, 26);
            this.guardarToolStripMenuItem.Text = "Guardar";
            this.guardarToolStripMenuItem.Click += new System.EventHandler(this.btGuardar_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(134, 6);
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(137, 26);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // ediciónToolStripMenuItem
            // 
            this.ediciónToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itCortar,
            this.itCopiar,
            this.itPegar,
            this.toolStripMenuItem4,
            this.itVaciar,
            this.toolStripMenuItem5,
            this.itDeshacer,
            this.itRehacer});
            this.ediciónToolStripMenuItem.Name = "ediciónToolStripMenuItem";
            this.ediciónToolStripMenuItem.Size = new System.Drawing.Size(70, 24);
            this.ediciónToolStripMenuItem.Text = "Edición";
            // 
            // itCortar
            // 
            this.itCortar.Name = "itCortar";
            this.itCortar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.itCortar.Size = new System.Drawing.Size(214, 26);
            this.itCortar.Text = "Cortar";
            this.itCortar.Click += new System.EventHandler(this.cortarToolStripMenuItem_Click);
            // 
            // itCopiar
            // 
            this.itCopiar.Name = "itCopiar";
            this.itCopiar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.itCopiar.Size = new System.Drawing.Size(214, 26);
            this.itCopiar.Text = "Copiar";
            this.itCopiar.Click += new System.EventHandler(this.copiarToolStripMenuItem_Click);
            // 
            // itPegar
            // 
            this.itPegar.Name = "itPegar";
            this.itPegar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.itPegar.Size = new System.Drawing.Size(214, 26);
            this.itPegar.Text = "Pegar";
            this.itPegar.Click += new System.EventHandler(this.pegarToolStripMenuItem_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(211, 6);
            // 
            // itVaciar
            // 
            this.itVaciar.Name = "itVaciar";
            this.itVaciar.Size = new System.Drawing.Size(214, 26);
            this.itVaciar.Text = "Vaciar Portapapeles";
            this.itVaciar.Click += new System.EventHandler(this.vaciarPortapapelesToolStripMenuItem_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(211, 6);
            // 
            // itDeshacer
            // 
            this.itDeshacer.Name = "itDeshacer";
            this.itDeshacer.Size = new System.Drawing.Size(214, 26);
            this.itDeshacer.Text = "Deshacer";
            this.itDeshacer.Click += new System.EventHandler(this.itDeshacer_Click);
            // 
            // itRehacer
            // 
            this.itRehacer.Name = "itRehacer";
            this.itRehacer.Size = new System.Drawing.Size(214, 26);
            this.itRehacer.Text = "Rehacer";
            this.itRehacer.Click += new System.EventHandler(this.itRehacer_Click);
            // 
            // formatoToolStripMenuItem1
            // 
            this.formatoToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.alineaciónToolStripMenuItem,
            this.estiloToolStripMenuItem,
            this.itColores});
            this.formatoToolStripMenuItem1.Name = "formatoToolStripMenuItem1";
            this.formatoToolStripMenuItem1.Size = new System.Drawing.Size(77, 24);
            this.formatoToolStripMenuItem1.Text = "&Formato";
            // 
            // alineaciónToolStripMenuItem
            // 
            this.alineaciónToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itDere,
            this.itCent,
            this.itIzq});
            this.alineaciónToolStripMenuItem.Name = "alineaciónToolStripMenuItem";
            this.alineaciónToolStripMenuItem.Size = new System.Drawing.Size(154, 26);
            this.alineaciónToolStripMenuItem.Text = "Alineación";
            // 
            // itDere
            // 
            this.itDere.Name = "itDere";
            this.itDere.Size = new System.Drawing.Size(146, 26);
            this.itDere.Text = "Derecha";
            this.itDere.Click += new System.EventHandler(this.itDere_Click);
            // 
            // itCent
            // 
            this.itCent.Name = "itCent";
            this.itCent.Size = new System.Drawing.Size(146, 26);
            this.itCent.Text = "Centrado";
            this.itCent.Click += new System.EventHandler(this.itCent_Click);
            // 
            // itIzq
            // 
            this.itIzq.Name = "itIzq";
            this.itIzq.Size = new System.Drawing.Size(146, 26);
            this.itIzq.Text = "Izquierda";
            this.itIzq.Click += new System.EventHandler(this.itIzq_Click);
            // 
            // estiloToolStripMenuItem
            // 
            this.estiloToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itNegrita,
            this.itCursiva,
            this.itSubrayado,
            this.itTachado});
            this.estiloToolStripMenuItem.Name = "estiloToolStripMenuItem";
            this.estiloToolStripMenuItem.Size = new System.Drawing.Size(154, 26);
            this.estiloToolStripMenuItem.Text = "Estilo";
            // 
            // itNegrita
            // 
            this.itNegrita.Name = "itNegrita";
            this.itNegrita.Size = new System.Drawing.Size(155, 26);
            this.itNegrita.Text = "Negrita";
            this.itNegrita.Click += new System.EventHandler(this.itNegrita_Click);
            // 
            // itCursiva
            // 
            this.itCursiva.Name = "itCursiva";
            this.itCursiva.Size = new System.Drawing.Size(155, 26);
            this.itCursiva.Text = "Crusiva";
            this.itCursiva.Click += new System.EventHandler(this.itCursiva_Click);
            // 
            // itSubrayado
            // 
            this.itSubrayado.Name = "itSubrayado";
            this.itSubrayado.Size = new System.Drawing.Size(155, 26);
            this.itSubrayado.Text = "Subrayado";
            this.itSubrayado.Click += new System.EventHandler(this.itSubrayado_Click);
            // 
            // itTachado
            // 
            this.itTachado.Name = "itTachado";
            this.itTachado.Size = new System.Drawing.Size(155, 26);
            this.itTachado.Text = "Tachado";
            this.itTachado.Click += new System.EventHandler(this.itTachado_Click);
            // 
            // itColores
            // 
            this.itColores.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itRojo,
            this.itVerde,
            this.itAzul,
            this.itGris,
            this.itAmarillo,
            this.itNegro,
            this.itNaranja});
            this.itColores.Name = "itColores";
            this.itColores.Size = new System.Drawing.Size(154, 26);
            this.itColores.Text = "Colores";
            // 
            // itRojo
            // 
            this.itRojo.Name = "itRojo";
            this.itRojo.Size = new System.Drawing.Size(141, 26);
            this.itRojo.Text = "Rojo";
            this.itRojo.Click += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // itVerde
            // 
            this.itVerde.Name = "itVerde";
            this.itVerde.Size = new System.Drawing.Size(141, 26);
            this.itVerde.Text = "Verde";
            this.itVerde.Click += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // itAzul
            // 
            this.itAzul.Name = "itAzul";
            this.itAzul.Size = new System.Drawing.Size(141, 26);
            this.itAzul.Text = "Azul";
            this.itAzul.Click += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // itGris
            // 
            this.itGris.Name = "itGris";
            this.itGris.Size = new System.Drawing.Size(141, 26);
            this.itGris.Text = "Gris";
            this.itGris.Click += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // itAmarillo
            // 
            this.itAmarillo.Name = "itAmarillo";
            this.itAmarillo.Size = new System.Drawing.Size(141, 26);
            this.itAmarillo.Text = "Amarillo";
            this.itAmarillo.Click += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // itNegro
            // 
            this.itNegro.Name = "itNegro";
            this.itNegro.Size = new System.Drawing.Size(141, 26);
            this.itNegro.Text = "Negro";
            this.itNegro.Click += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // itNaranja
            // 
            this.itNaranja.Name = "itNaranja";
            this.itNaranja.Size = new System.Drawing.Size(141, 26);
            this.itNaranja.Text = "Naranja";
            this.itNaranja.Click += new System.EventHandler(this.lbColores_SelectedIndexChanged);
            // 
            // ayudaToolStripMenuItem1
            // 
            this.ayudaToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.acercaDeToolStripMenuItem});
            this.ayudaToolStripMenuItem1.Name = "ayudaToolStripMenuItem1";
            this.ayudaToolStripMenuItem1.Size = new System.Drawing.Size(63, 24);
            this.ayudaToolStripMenuItem1.Text = "Ayuda";
            // 
            // acercaDeToolStripMenuItem
            // 
            this.acercaDeToolStripMenuItem.Name = "acercaDeToolStripMenuItem";
            this.acercaDeToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.acercaDeToolStripMenuItem.Text = "Acerca De";
            this.acercaDeToolStripMenuItem.Click += new System.EventHandler(this.acercaDeToolStripMenuItem_Click);
            // 
            // rtbEditor
            // 
            this.rtbEditor.ContextMenuStrip = this.contextMenuStrip1;
            this.rtbEditor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbEditor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbEditor.Location = new System.Drawing.Point(0, 257);
            this.rtbEditor.Name = "rtbEditor";
            this.rtbEditor.Size = new System.Drawing.Size(1003, 309);
            this.rtbEditor.TabIndex = 11;
            this.rtbEditor.Text = "";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoToolStripMenuItem,
            this.edicionToolStripMenuItem,
            this.formatoToolStripMenuItem,
            this.ayudaToolStripMenuItem,
            this.vaciarPortapapelesToolStripMenuItem,
            this.toolStripSeparator1,
            this.toolStripMenuItem7,
            this.toolStripMenuItem8});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(209, 160);
            // 
            // archivoToolStripMenuItem
            // 
            this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            this.archivoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X)));
            this.archivoToolStripMenuItem.Size = new System.Drawing.Size(208, 24);
            this.archivoToolStripMenuItem.Text = "Cortar";
            this.archivoToolStripMenuItem.Click += new System.EventHandler(this.cortarToolStripMenuItem_Click);
            // 
            // edicionToolStripMenuItem
            // 
            this.edicionToolStripMenuItem.Name = "edicionToolStripMenuItem";
            this.edicionToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C)));
            this.edicionToolStripMenuItem.Size = new System.Drawing.Size(208, 24);
            this.edicionToolStripMenuItem.Text = "Copiar";
            this.edicionToolStripMenuItem.Click += new System.EventHandler(this.copiarToolStripMenuItem_Click);
            // 
            // formatoToolStripMenuItem
            // 
            this.formatoToolStripMenuItem.Name = "formatoToolStripMenuItem";
            this.formatoToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V)));
            this.formatoToolStripMenuItem.Size = new System.Drawing.Size(208, 24);
            this.formatoToolStripMenuItem.Text = "Pegar";
            this.formatoToolStripMenuItem.Click += new System.EventHandler(this.pegarToolStripMenuItem_Click);
            // 
            // ayudaToolStripMenuItem
            // 
            this.ayudaToolStripMenuItem.Name = "ayudaToolStripMenuItem";
            this.ayudaToolStripMenuItem.Size = new System.Drawing.Size(205, 6);
            // 
            // vaciarPortapapelesToolStripMenuItem
            // 
            this.vaciarPortapapelesToolStripMenuItem.Name = "vaciarPortapapelesToolStripMenuItem";
            this.vaciarPortapapelesToolStripMenuItem.Size = new System.Drawing.Size(208, 24);
            this.vaciarPortapapelesToolStripMenuItem.Text = "Vaciar Portapapeles";
            this.vaciarPortapapelesToolStripMenuItem.Click += new System.EventHandler(this.vaciarPortapapelesToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(205, 6);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(208, 24);
            this.toolStripMenuItem7.Text = "Deshacer";
            this.toolStripMenuItem7.Click += new System.EventHandler(this.itDeshacer_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(208, 24);
            this.toolStripMenuItem8.Text = "Rehacer";
            this.toolStripMenuItem8.Click += new System.EventHandler(this.itRehacer_Click);
            // 
            // fmEditorTextos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1003, 566);
            this.Controls.Add(this.rtbEditor);
            this.Controls.Add(this.panel1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "fmEditorTextos";
            this.Text = "Editor de textos";
            this.Load += new System.EventHandler(this.fmEditorTextos_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gbAlineacion.ResumeLayout(false);
            this.gbAlineacion.PerformLayout();
            this.gbEstilo.ResumeLayout(false);
            this.gbEstilo.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox lbColores;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btGuardar;
        private System.Windows.Forms.Button btAbrir;
        private System.Windows.Forms.ComboBox cbTamanio;
        private System.Windows.Forms.ComboBox cbFuente;
        private System.Windows.Forms.RichTextBox rtbEditor;
        private System.Windows.Forms.GroupBox gbEstilo;
        private System.Windows.Forms.CheckBox cbNegrita;
        private System.Windows.Forms.CheckBox cbTachado;
        private System.Windows.Forms.CheckBox cbCursiva;
        private System.Windows.Forms.CheckBox cbSubrayado;
        private System.Windows.Forms.GroupBox gbAlineacion;
        private System.Windows.Forms.RadioButton rbDerecha;
        private System.Windows.Forms.RadioButton rbCentrada;
        private System.Windows.Forms.RadioButton rbIzquierda;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem edicionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formatoToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ediciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formatoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ayudaToolStripMenuItem1;
        private System.Windows.Forms.ToolTip totiColor;
        private System.Windows.Forms.ToolStripMenuItem nuevoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem guardarToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itCortar;
        private System.Windows.Forms.ToolStripMenuItem itCopiar;
        private System.Windows.Forms.ToolStripMenuItem itPegar;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem itVaciar;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem acercaDeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itDeshacer;
        private System.Windows.Forms.ToolStripMenuItem itRehacer;
        private System.Windows.Forms.ToolStripMenuItem alineaciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itDere;
        private System.Windows.Forms.ToolStripMenuItem itCent;
        private System.Windows.Forms.ToolStripMenuItem itIzq;
        private System.Windows.Forms.ToolStripMenuItem estiloToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itColores;
        private System.Windows.Forms.ToolStripMenuItem itNegrita;
        private System.Windows.Forms.ToolStripMenuItem itCursiva;
        private System.Windows.Forms.ToolStripMenuItem itSubrayado;
        private System.Windows.Forms.ToolStripMenuItem itTachado;
        private System.Windows.Forms.ToolStripMenuItem itRojo;
        private System.Windows.Forms.ToolStripMenuItem itVerde;
        private System.Windows.Forms.ToolStripMenuItem itAzul;
        private System.Windows.Forms.ToolStripMenuItem itGris;
        private System.Windows.Forms.ToolStripMenuItem itAmarillo;
        private System.Windows.Forms.ToolStripMenuItem itNaranja;
        private System.Windows.Forms.ToolStripMenuItem itNegro;
        private System.Windows.Forms.ToolStripSeparator ayudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vaciarPortapapelesToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
    }
}

