﻿namespace EdicionDatos
{
    partial class fmIntroDatos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbNombre = new System.Windows.Forms.Label();
            this.tbNombreMostra = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tbLocalidad = new System.Windows.Forms.TextBox();
            this.tbDireccion = new System.Windows.Forms.TextBox();
            this.tbTelefono = new System.Windows.Forms.TextBox();
            this.tbDni = new System.Windows.Forms.TextBox();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.tbContrasenya = new System.Windows.Forms.TextBox();
            this.tbContrasenya2 = new System.Windows.Forms.TextBox();
            this.tbCodigoPostal = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btMenuPrincipal = new System.Windows.Forms.Button();
            this.btAceptar = new System.Windows.Forms.Button();
            this.btCancelar = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbNombre
            // 
            this.lbNombre.AutoSize = true;
            this.lbNombre.Location = new System.Drawing.Point(106, 62);
            this.lbNombre.Name = "lbNombre";
            this.lbNombre.Size = new System.Drawing.Size(58, 17);
            this.lbNombre.TabIndex = 0;
            this.lbNombre.Text = "Nombre";
            // 
            // tbNombreMostra
            // 
            this.tbNombreMostra.Location = new System.Drawing.Point(109, 82);
            this.tbNombreMostra.Name = "tbNombreMostra";
            this.tbNombreMostra.Size = new System.Drawing.Size(438, 22);
            this.tbNombreMostra.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(106, 127);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Dirección";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(106, 206);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Teléfono";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(106, 292);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "DNI/CIF";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(379, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Localidad";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(379, 206);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 17);
            this.label5.TabIndex = 6;
            this.label5.Text = "email";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(379, 292);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(81, 17);
            this.label6.TabIndex = 7;
            this.label6.Text = "Contraseña";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(379, 358);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(124, 17);
            this.label7.TabIndex = 8;
            this.label7.Text = "Repite contraseña";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(581, 127);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 17);
            this.label8.TabIndex = 9;
            this.label8.Text = "Código postal";
            // 
            // tbLocalidad
            // 
            this.tbLocalidad.Location = new System.Drawing.Point(382, 147);
            this.tbLocalidad.Name = "tbLocalidad";
            this.tbLocalidad.Size = new System.Drawing.Size(150, 22);
            this.tbLocalidad.TabIndex = 5;
            // 
            // tbDireccion
            // 
            this.tbDireccion.Location = new System.Drawing.Point(109, 147);
            this.tbDireccion.Name = "tbDireccion";
            this.tbDireccion.Size = new System.Drawing.Size(150, 22);
            this.tbDireccion.TabIndex = 2;
            // 
            // tbTelefono
            // 
            this.tbTelefono.Location = new System.Drawing.Point(109, 226);
            this.tbTelefono.MaxLength = 9;
            this.tbTelefono.Name = "tbTelefono";
            this.tbTelefono.Size = new System.Drawing.Size(150, 22);
            this.tbTelefono.TabIndex = 3;
            this.tbTelefono.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCodigoPostal_KeyPress);
            // 
            // tbDni
            // 
            this.tbDni.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDni.Location = new System.Drawing.Point(109, 312);
            this.tbDni.MaxLength = 9;
            this.tbDni.Name = "tbDni";
            this.tbDni.Size = new System.Drawing.Size(150, 22);
            this.tbDni.TabIndex = 4;
            this.tbDni.TextChanged += new System.EventHandler(this.tbDni_TextChanged);
            this.tbDni.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDni_KeyPress);
            this.tbDni.Validating += new System.ComponentModel.CancelEventHandler(this.tbDni_Validating);
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(382, 238);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(264, 22);
            this.tbEmail.TabIndex = 7;
            this.tbEmail.Validating += new System.ComponentModel.CancelEventHandler(this.tbEmail_Validating);
            // 
            // tbContrasenya
            // 
            this.tbContrasenya.Location = new System.Drawing.Point(382, 312);
            this.tbContrasenya.Name = "tbContrasenya";
            this.tbContrasenya.PasswordChar = '*';
            this.tbContrasenya.Size = new System.Drawing.Size(150, 22);
            this.tbContrasenya.TabIndex = 8;
            this.tbContrasenya.Validating += new System.ComponentModel.CancelEventHandler(this.tbContrasenya_Validating);
            // 
            // tbContrasenya2
            // 
            this.tbContrasenya2.Location = new System.Drawing.Point(382, 389);
            this.tbContrasenya2.Name = "tbContrasenya2";
            this.tbContrasenya2.PasswordChar = '*';
            this.tbContrasenya2.Size = new System.Drawing.Size(150, 22);
            this.tbContrasenya2.TabIndex = 9;
            this.tbContrasenya2.Validating += new System.ComponentModel.CancelEventHandler(this.tbContrasenya2_Validating);
            // 
            // tbCodigoPostal
            // 
            this.tbCodigoPostal.Location = new System.Drawing.Point(584, 147);
            this.tbCodigoPostal.MaxLength = 5;
            this.tbCodigoPostal.Name = "tbCodigoPostal";
            this.tbCodigoPostal.Size = new System.Drawing.Size(91, 22);
            this.tbCodigoPostal.TabIndex = 6;
            this.tbCodigoPostal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCodigoPostal_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(553, 82);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(13, 17);
            this.label9.TabIndex = 18;
            this.label9.Text = "*";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(503, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(276, 17);
            this.label10.TabIndex = 19;
            this.label10.Text = "Los datos marcados con * son obligatorios";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(650, 394);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(137, 145);
            this.label11.TabIndex = 20;
            this.label11.Text = "11111111H\r\nA58818501\r\nP0300008J\r\nG03548005\r\nP0305900C";
            // 
            // btMenuPrincipal
            // 
            this.btMenuPrincipal.AutoSize = true;
            this.btMenuPrincipal.Location = new System.Drawing.Point(262, 431);
            this.btMenuPrincipal.Name = "btMenuPrincipal";
            this.btMenuPrincipal.Size = new System.Drawing.Size(144, 27);
            this.btMenuPrincipal.TabIndex = 10;
            this.btMenuPrincipal.Text = "Mostrar en Principal";
            this.btMenuPrincipal.UseVisualStyleBackColor = true;
            this.btMenuPrincipal.Click += new System.EventHandler(this.btMenuPrincipal_Click);
            // 
            // btAceptar
            // 
            this.btAceptar.AutoSize = true;
            this.btAceptar.Location = new System.Drawing.Point(228, 478);
            this.btAceptar.Name = "btAceptar";
            this.btAceptar.Size = new System.Drawing.Size(75, 27);
            this.btAceptar.TabIndex = 11;
            this.btAceptar.Text = "Aceptar";
            this.btAceptar.UseVisualStyleBackColor = true;
            this.btAceptar.Click += new System.EventHandler(this.btAceptar_Click);
            // 
            // btCancelar
            // 
            this.btCancelar.AutoSize = true;
            this.btCancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btCancelar.Location = new System.Drawing.Point(373, 478);
            this.btCancelar.Name = "btCancelar";
            this.btCancelar.Size = new System.Drawing.Size(75, 27);
            this.btCancelar.TabIndex = 12;
            this.btCancelar.Text = "Cancelar";
            this.btCancelar.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(265, 312);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(13, 17);
            this.label12.TabIndex = 24;
            this.label12.Text = "*";
            // 
            // fmIntroDatos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(818, 548);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.btCancelar);
            this.Controls.Add(this.btAceptar);
            this.Controls.Add(this.btMenuPrincipal);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.tbCodigoPostal);
            this.Controls.Add(this.tbContrasenya2);
            this.Controls.Add(this.tbContrasenya);
            this.Controls.Add(this.tbEmail);
            this.Controls.Add(this.tbDni);
            this.Controls.Add(this.tbTelefono);
            this.Controls.Add(this.tbDireccion);
            this.Controls.Add(this.tbLocalidad);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbNombreMostra);
            this.Controls.Add(this.lbNombre);
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "fmIntroDatos";
            this.Text = "fmIntroDatos";
            this.Load += new System.EventHandler(this.fmIntroDatos_Load);
            this.Shown += new System.EventHandler(this.fmIntroDatos_Shown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fmIntroDatos_KeyPress);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbNombre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btMenuPrincipal;
        private System.Windows.Forms.Button btAceptar;
        private System.Windows.Forms.Button btCancelar;
        private System.Windows.Forms.Label label12;
        public System.Windows.Forms.TextBox tbNombreMostra;
        public System.Windows.Forms.TextBox tbLocalidad;
        public System.Windows.Forms.TextBox tbDireccion;
        public System.Windows.Forms.TextBox tbTelefono;
        public System.Windows.Forms.TextBox tbDni;
        public System.Windows.Forms.TextBox tbEmail;
        public System.Windows.Forms.TextBox tbContrasenya;
        public System.Windows.Forms.TextBox tbContrasenya2;
        public System.Windows.Forms.TextBox tbCodigoPostal;
    }
}