﻿namespace _06Editor
{
    partial class fmEditor
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tsBarraEstandar = new System.Windows.Forms.ToolStrip();
            this.cmnBarras = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmBarraHerramEstandar = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmBarraDeHerramFormato = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmBarraDeEstado = new System.Windows.Forms.ToolStripMenuItem();
            this.tsbNuevo = new System.Windows.Forms.ToolStripButton();
            this.tsbAbrir = new System.Windows.Forms.ToolStripButton();
            this.tsbGuardar = new System.Windows.Forms.ToolStripButton();
            this.tsbImprimir = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbCortar = new System.Windows.Forms.ToolStripButton();
            this.tsbCopiar = new System.Windows.Forms.ToolStripButton();
            this.tsbPegar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbDeshacer = new System.Windows.Forms.ToolStripButton();
            this.tsbRehacer = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbCopiarFormato = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.itQuitarFormato = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.tsBarraFormato = new System.Windows.Forms.ToolStrip();
            this.tsbNegrita = new System.Windows.Forms.ToolStripButton();
            this.tsbCursiva = new System.Windows.Forms.ToolStripButton();
            this.tsbSubrayado = new System.Windows.Forms.ToolStripButton();
            this.tsbTachado = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbIzquierda = new System.Windows.Forms.ToolStripButton();
            this.tsbCentro = new System.Windows.Forms.ToolStripButton();
            this.tsbDerecha = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.cbFuentes = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.cbTamanyo = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbColores = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.stEstadoEditor = new System.Windows.Forms.StatusStrip();
            this.sl1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sl2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sl3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sl4 = new System.Windows.Forms.ToolStripStatusLabel();
            this.sl5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.mnsEditor = new System.Windows.Forms.MenuStrip();
            this.archivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itNuevo = new System.Windows.Forms.ToolStripMenuItem();
            this.itAbrir = new System.Windows.Forms.ToolStripMenuItem();
            this.itGuardar = new System.Windows.Forms.ToolStripMenuItem();
            this.itGuardarComo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.itImprimir = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ediciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itDeshacer = new System.Windows.Forms.ToolStripMenuItem();
            this.itRehacer = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.itCortar = new System.Windows.Forms.ToolStripMenuItem();
            this.itPegar = new System.Windows.Forms.ToolStripMenuItem();
            this.itCopiar = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripSeparator();
            this.itBorrar = new System.Windows.Forms.ToolStripMenuItem();
            this.itSeleccionarTodo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripSeparator();
            this.itIrA = new System.Windows.Forms.ToolStripMenuItem();
            this.formatoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itFuentes = new System.Windows.Forms.ToolStripMenuItem();
            this.itColorDeFondo = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripSeparator();
            this.itMargenes = new System.Windows.Forms.ToolStripMenuItem();
            this.itJustificacion = new System.Windows.Forms.ToolStripMenuItem();
            this.itDerecha = new System.Windows.Forms.ToolStripMenuItem();
            this.itCentro = new System.Windows.Forms.ToolStripMenuItem();
            this.itIzquierda = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripSeparator();
            this.itVinyetas = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripSeparator();
            this.itFormatoPagina = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripSeparator();
            this.quitarFormatosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itBarraDeHerramientasEstándar = new System.Windows.Forms.ToolStripMenuItem();
            this.itBarraDeHerramientasFormato = new System.Windows.Forms.ToolStripMenuItem();
            this.itBarraDeEstado = new System.Windows.Forms.ToolStripMenuItem();
            this.ayudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmAcercaDe = new System.Windows.Forms.ToolStripMenuItem();
            this.indiceAyudaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ayudaGeneralToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rtbEditor = new System.Windows.Forms.RichTextBox();
            this.cmnEdicion = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.deshacerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rehacerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripSeparator();
            this.cortarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copiarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pegarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem11 = new System.Windows.Forms.ToolStripSeparator();
            this.suprimirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripSeparator();
            this.seleccionarTodoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.dlgAbrir = new System.Windows.Forms.OpenFileDialog();
            this.dlgGuardar = new System.Windows.Forms.SaveFileDialog();
            this.dlgImprimir = new System.Windows.Forms.PrintDialog();
            this.printDocEditor = new System.Drawing.Printing.PrintDocument();
            this.dlgColor = new System.Windows.Forms.ColorDialog();
            this.dlgFuente = new System.Windows.Forms.FontDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.tsBarraEstandar.SuspendLayout();
            this.cmnBarras.SuspendLayout();
            this.tsBarraFormato.SuspendLayout();
            this.stEstadoEditor.SuspendLayout();
            this.mnsEditor.SuspendLayout();
            this.cmnEdicion.SuspendLayout();
            this.SuspendLayout();
            // 
            // tsBarraEstandar
            // 
            this.tsBarraEstandar.ContextMenuStrip = this.cmnBarras;
            this.tsBarraEstandar.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.tsBarraEstandar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbNuevo,
            this.tsbAbrir,
            this.tsbGuardar,
            this.tsbImprimir,
            this.toolStripSeparator1,
            this.tsbCortar,
            this.tsbCopiar,
            this.tsbPegar,
            this.toolStripSeparator2,
            this.tsbDeshacer,
            this.tsbRehacer,
            this.toolStripSeparator3,
            this.tsbCopiarFormato,
            this.toolStripSeparator4,
            this.itQuitarFormato,
            this.toolStripSeparator5});
            this.tsBarraEstandar.Location = new System.Drawing.Point(0, 28);
            this.tsBarraEstandar.Name = "tsBarraEstandar";
            this.tsBarraEstandar.Size = new System.Drawing.Size(1073, 27);
            this.tsBarraEstandar.TabIndex = 0;
            this.tsBarraEstandar.Text = "toolStrip1";
            // 
            // cmnBarras
            // 
            this.cmnBarras.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cmnBarras.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmBarraHerramEstandar,
            this.tsmBarraDeHerramFormato,
            this.tsmBarraDeEstado});
            this.cmnBarras.Name = "cmnBarras";
            this.cmnBarras.Size = new System.Drawing.Size(289, 82);
            // 
            // tsmBarraHerramEstandar
            // 
            this.tsmBarraHerramEstandar.Checked = true;
            this.tsmBarraHerramEstandar.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsmBarraHerramEstandar.Name = "tsmBarraHerramEstandar";
            this.tsmBarraHerramEstandar.Size = new System.Drawing.Size(288, 26);
            this.tsmBarraHerramEstandar.Text = "Barra de Herramientas estándar";
            this.tsmBarraHerramEstandar.Click += new System.EventHandler(this.itBarraDeHerramientasEstándar_Click);
            // 
            // tsmBarraDeHerramFormato
            // 
            this.tsmBarraDeHerramFormato.Checked = true;
            this.tsmBarraDeHerramFormato.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsmBarraDeHerramFormato.Name = "tsmBarraDeHerramFormato";
            this.tsmBarraDeHerramFormato.Size = new System.Drawing.Size(288, 26);
            this.tsmBarraDeHerramFormato.Text = "Barra de Herramientas Formato";
            this.tsmBarraDeHerramFormato.Click += new System.EventHandler(this.itBarraDeHerramientasFormato_Click);
            // 
            // tsmBarraDeEstado
            // 
            this.tsmBarraDeEstado.Checked = true;
            this.tsmBarraDeEstado.CheckState = System.Windows.Forms.CheckState.Checked;
            this.tsmBarraDeEstado.Name = "tsmBarraDeEstado";
            this.tsmBarraDeEstado.Size = new System.Drawing.Size(288, 26);
            this.tsmBarraDeEstado.Text = "Barra de Estado";
            this.tsmBarraDeEstado.Click += new System.EventHandler(this.itBarraDeEstado_Click);
            // 
            // tsbNuevo
            // 
            this.tsbNuevo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbNuevo.Image = global::_06Editor.Properties.Resources.NUEVO;
            this.tsbNuevo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNuevo.Name = "tsbNuevo";
            this.tsbNuevo.Size = new System.Drawing.Size(24, 24);
            this.tsbNuevo.Text = "toolStripButton1";
            this.tsbNuevo.ToolTipText = "Crear Nuevo archivo";
            this.tsbNuevo.Click += new System.EventHandler(this.itNuevo_Click);
            // 
            // tsbAbrir
            // 
            this.tsbAbrir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAbrir.Image = global::_06Editor.Properties.Resources.ABRIR;
            this.tsbAbrir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAbrir.Name = "tsbAbrir";
            this.tsbAbrir.Size = new System.Drawing.Size(24, 24);
            this.tsbAbrir.Text = "toolStripButton2";
            this.tsbAbrir.Click += new System.EventHandler(this.itAbrir_Click);
            // 
            // tsbGuardar
            // 
            this.tsbGuardar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbGuardar.Image = global::_06Editor.Properties.Resources.guardar;
            this.tsbGuardar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbGuardar.Name = "tsbGuardar";
            this.tsbGuardar.Size = new System.Drawing.Size(24, 24);
            this.tsbGuardar.Text = "toolStripButton3";
            this.tsbGuardar.Click += new System.EventHandler(this.itGuardar_Click);
            // 
            // tsbImprimir
            // 
            this.tsbImprimir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbImprimir.Image = global::_06Editor.Properties.Resources.PrintDocumentControl_697_24;
            this.tsbImprimir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbImprimir.Name = "tsbImprimir";
            this.tsbImprimir.Size = new System.Drawing.Size(24, 24);
            this.tsbImprimir.Text = "toolStripButton4";
            this.tsbImprimir.Click += new System.EventHandler(this.itImprimir_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // tsbCortar
            // 
            this.tsbCortar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCortar.Image = global::_06Editor.Properties.Resources.CORTA;
            this.tsbCortar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCortar.Name = "tsbCortar";
            this.tsbCortar.Size = new System.Drawing.Size(24, 24);
            this.tsbCortar.Text = "toolStripButton5";
            this.tsbCortar.Click += new System.EventHandler(this.itCortar_Click);
            // 
            // tsbCopiar
            // 
            this.tsbCopiar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCopiar.Image = global::_06Editor.Properties.Resources.COPIA;
            this.tsbCopiar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCopiar.Name = "tsbCopiar";
            this.tsbCopiar.Size = new System.Drawing.Size(24, 24);
            this.tsbCopiar.Text = "toolStripButton6";
            this.tsbCopiar.Click += new System.EventHandler(this.itCopiar_Click);
            // 
            // tsbPegar
            // 
            this.tsbPegar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbPegar.Image = global::_06Editor.Properties.Resources.PEGA;
            this.tsbPegar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbPegar.Name = "tsbPegar";
            this.tsbPegar.Size = new System.Drawing.Size(24, 24);
            this.tsbPegar.Text = "toolStripButton7";
            this.tsbPegar.Click += new System.EventHandler(this.itPegar_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // tsbDeshacer
            // 
            this.tsbDeshacer.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDeshacer.Image = global::_06Editor.Properties.Resources.DESHAZ;
            this.tsbDeshacer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDeshacer.Name = "tsbDeshacer";
            this.tsbDeshacer.Size = new System.Drawing.Size(24, 24);
            this.tsbDeshacer.Text = "toolStripButton8";
            this.tsbDeshacer.Click += new System.EventHandler(this.itDeshacer_Click);
            // 
            // tsbRehacer
            // 
            this.tsbRehacer.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbRehacer.Image = global::_06Editor.Properties.Resources.rehacer;
            this.tsbRehacer.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbRehacer.Name = "tsbRehacer";
            this.tsbRehacer.Size = new System.Drawing.Size(24, 24);
            this.tsbRehacer.Text = "toolStripButton9";
            this.tsbRehacer.Click += new System.EventHandler(this.itRehacer_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 27);
            // 
            // tsbCopiarFormato
            // 
            this.tsbCopiarFormato.CheckOnClick = true;
            this.tsbCopiarFormato.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCopiarFormato.Image = global::_06Editor.Properties.Resources.CopiarFormatos;
            this.tsbCopiarFormato.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCopiarFormato.Name = "tsbCopiarFormato";
            this.tsbCopiarFormato.Size = new System.Drawing.Size(24, 24);
            this.tsbCopiarFormato.Text = "toolStripButton10";
            this.tsbCopiarFormato.Click += new System.EventHandler(this.tsbCopiarFormato_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 27);
            // 
            // itQuitarFormato
            // 
            this.itQuitarFormato.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.itQuitarFormato.Image = global::_06Editor.Properties.Resources.ESTILO;
            this.itQuitarFormato.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.itQuitarFormato.Name = "itQuitarFormato";
            this.itQuitarFormato.Size = new System.Drawing.Size(24, 24);
            this.itQuitarFormato.Text = "toolStripButton11";
            this.itQuitarFormato.Click += new System.EventHandler(this.itQuitarFormato_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 27);
            // 
            // tsBarraFormato
            // 
            this.tsBarraFormato.ContextMenuStrip = this.cmnBarras;
            this.tsBarraFormato.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.tsBarraFormato.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbNegrita,
            this.tsbCursiva,
            this.tsbSubrayado,
            this.tsbTachado,
            this.toolStripSeparator6,
            this.tsbIzquierda,
            this.tsbCentro,
            this.tsbDerecha,
            this.toolStripSeparator7,
            this.cbFuentes,
            this.toolStripSeparator8,
            this.cbTamanyo,
            this.toolStripSeparator9,
            this.tsbColores,
            this.toolStripSeparator10});
            this.tsBarraFormato.Location = new System.Drawing.Point(0, 55);
            this.tsBarraFormato.Name = "tsBarraFormato";
            this.tsBarraFormato.Size = new System.Drawing.Size(1073, 28);
            this.tsBarraFormato.TabIndex = 1;
            this.tsBarraFormato.Text = "toolStrip2";
            // 
            // tsbNegrita
            // 
            this.tsbNegrita.CheckOnClick = true;
            this.tsbNegrita.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbNegrita.Image = global::_06Editor.Properties.Resources.negrita;
            this.tsbNegrita.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNegrita.Name = "tsbNegrita";
            this.tsbNegrita.Size = new System.Drawing.Size(24, 25);
            this.tsbNegrita.Text = "toolStripButton12";
            this.tsbNegrita.Click += new System.EventHandler(this.tsbNegrita_Click);
            // 
            // tsbCursiva
            // 
            this.tsbCursiva.CheckOnClick = true;
            this.tsbCursiva.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCursiva.Image = global::_06Editor.Properties.Resources.cursiva;
            this.tsbCursiva.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCursiva.Name = "tsbCursiva";
            this.tsbCursiva.Size = new System.Drawing.Size(24, 25);
            this.tsbCursiva.Text = "toolStripButton13";
            this.tsbCursiva.Click += new System.EventHandler(this.tsbNegrita_Click);
            // 
            // tsbSubrayado
            // 
            this.tsbSubrayado.CheckOnClick = true;
            this.tsbSubrayado.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbSubrayado.Image = global::_06Editor.Properties.Resources.subrayado;
            this.tsbSubrayado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbSubrayado.Name = "tsbSubrayado";
            this.tsbSubrayado.Size = new System.Drawing.Size(24, 25);
            this.tsbSubrayado.Text = "toolStripButton14";
            this.tsbSubrayado.Click += new System.EventHandler(this.tsbNegrita_Click);
            // 
            // tsbTachado
            // 
            this.tsbTachado.CheckOnClick = true;
            this.tsbTachado.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbTachado.Image = global::_06Editor.Properties.Resources.tachado;
            this.tsbTachado.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTachado.Name = "tsbTachado";
            this.tsbTachado.Size = new System.Drawing.Size(24, 25);
            this.tsbTachado.Text = "toolStripButton15";
            this.tsbTachado.Click += new System.EventHandler(this.tsbNegrita_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 28);
            // 
            // tsbIzquierda
            // 
            this.tsbIzquierda.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbIzquierda.Image = global::_06Editor.Properties.Resources.IZQDA;
            this.tsbIzquierda.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbIzquierda.Name = "tsbIzquierda";
            this.tsbIzquierda.Size = new System.Drawing.Size(24, 25);
            this.tsbIzquierda.Text = "toolStripButton16";
            this.tsbIzquierda.Click += new System.EventHandler(this.tsbIzquierda_Click);
            // 
            // tsbCentro
            // 
            this.tsbCentro.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCentro.Image = global::_06Editor.Properties.Resources.CENTRO;
            this.tsbCentro.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCentro.Name = "tsbCentro";
            this.tsbCentro.Size = new System.Drawing.Size(24, 25);
            this.tsbCentro.Text = "toolStripButton17";
            this.tsbCentro.Click += new System.EventHandler(this.tsbCentro_Click);
            // 
            // tsbDerecha
            // 
            this.tsbDerecha.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbDerecha.Image = global::_06Editor.Properties.Resources.DCHA;
            this.tsbDerecha.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbDerecha.Name = "tsbDerecha";
            this.tsbDerecha.Size = new System.Drawing.Size(24, 25);
            this.tsbDerecha.Text = "toolStripButton18";
            this.tsbDerecha.Click += new System.EventHandler(this.tsbDerecha_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 28);
            // 
            // cbFuentes
            // 
            this.cbFuentes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFuentes.Name = "cbFuentes";
            this.cbFuentes.Size = new System.Drawing.Size(121, 28);
            this.cbFuentes.SelectedIndexChanged += new System.EventHandler(this.cbFuentes_SelectedIndexChanged);
            this.cbFuentes.Click += new System.EventHandler(this.cbFuentes_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 28);
            // 
            // cbTamanyo
            // 
            this.cbTamanyo.AutoSize = false;
            this.cbTamanyo.Items.AddRange(new object[] {
            "8",
            "10",
            "12",
            "14",
            "16",
            "18",
            "20",
            "24",
            "30",
            "36"});
            this.cbTamanyo.MaxLength = 2;
            this.cbTamanyo.Name = "cbTamanyo";
            this.cbTamanyo.Size = new System.Drawing.Size(75, 28);
            this.cbTamanyo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.cbTamanyo_KeyPress);
            this.cbTamanyo.TextChanged += new System.EventHandler(this.cbTamanyo_TextChanged);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 28);
            // 
            // tsbColores
            // 
            this.tsbColores.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbColores.Image = global::_06Editor.Properties.Resources.PALETA;
            this.tsbColores.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbColores.Name = "tsbColores";
            this.tsbColores.Size = new System.Drawing.Size(24, 25);
            this.tsbColores.Text = "toolStripButton19";
            this.tsbColores.Click += new System.EventHandler(this.tsbColores_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 28);
            // 
            // stEstadoEditor
            // 
            this.stEstadoEditor.ContextMenuStrip = this.cmnBarras;
            this.stEstadoEditor.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.stEstadoEditor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sl1,
            this.sl2,
            this.sl3,
            this.sl4,
            this.sl5});
            this.stEstadoEditor.Location = new System.Drawing.Point(0, 554);
            this.stEstadoEditor.Name = "stEstadoEditor";
            this.stEstadoEditor.Size = new System.Drawing.Size(1073, 24);
            this.stEstadoEditor.TabIndex = 2;
            this.stEstadoEditor.Text = "statusStrip1";
            this.stEstadoEditor.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.stEstadoEditor_ItemClicked);
            // 
            // sl1
            // 
            this.sl1.AutoSize = false;
            this.sl1.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sl1.BorderStyle = System.Windows.Forms.Border3DStyle.RaisedOuter;
            this.sl1.Name = "sl1";
            this.sl1.Size = new System.Drawing.Size(4, 19);
            this.sl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sl2
            // 
            this.sl2.AutoSize = false;
            this.sl2.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sl2.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.sl2.Name = "sl2";
            this.sl2.Size = new System.Drawing.Size(4, 19);
            // 
            // sl3
            // 
            this.sl3.AutoSize = false;
            this.sl3.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sl3.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.sl3.Name = "sl3";
            this.sl3.Size = new System.Drawing.Size(4, 19);
            // 
            // sl4
            // 
            this.sl4.AutoSize = false;
            this.sl4.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sl4.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.sl4.Name = "sl4";
            this.sl4.Size = new System.Drawing.Size(4, 19);
            // 
            // sl5
            // 
            this.sl5.AutoSize = false;
            this.sl5.BorderSides = System.Windows.Forms.ToolStripStatusLabelBorderSides.Left;
            this.sl5.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter;
            this.sl5.Name = "sl5";
            this.sl5.Size = new System.Drawing.Size(4, 19);
            this.sl5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mnsEditor
            // 
            this.mnsEditor.ContextMenuStrip = this.cmnBarras;
            this.mnsEditor.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mnsEditor.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.archivoToolStripMenuItem,
            this.ediciónToolStripMenuItem,
            this.formatoToolStripMenuItem,
            this.verToolStripMenuItem,
            this.ayudaToolStripMenuItem});
            this.mnsEditor.Location = new System.Drawing.Point(0, 0);
            this.mnsEditor.Name = "mnsEditor";
            this.mnsEditor.Size = new System.Drawing.Size(1073, 28);
            this.mnsEditor.TabIndex = 3;
            this.mnsEditor.Text = "menuStrip1";
            // 
            // archivoToolStripMenuItem
            // 
            this.archivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itNuevo,
            this.itAbrir,
            this.itGuardar,
            this.itGuardarComo,
            this.toolStripMenuItem1,
            this.itImprimir,
            this.toolStripMenuItem2,
            this.salirToolStripMenuItem});
            this.archivoToolStripMenuItem.Name = "archivoToolStripMenuItem";
            this.archivoToolStripMenuItem.Size = new System.Drawing.Size(71, 24);
            this.archivoToolStripMenuItem.Text = "Archivo";
            // 
            // itNuevo
            // 
            this.itNuevo.Image = global::_06Editor.Properties.Resources.NUEVO;
            this.itNuevo.Name = "itNuevo";
            this.itNuevo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.U)));
            this.itNuevo.Size = new System.Drawing.Size(216, 26);
            this.itNuevo.Text = "&Nuevo";
            this.itNuevo.Click += new System.EventHandler(this.itNuevo_Click);
            // 
            // itAbrir
            // 
            this.itAbrir.Image = global::_06Editor.Properties.Resources.ABRIR;
            this.itAbrir.Name = "itAbrir";
            this.itAbrir.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.A)));
            this.itAbrir.Size = new System.Drawing.Size(216, 26);
            this.itAbrir.Text = "&Abrir";
            this.itAbrir.Click += new System.EventHandler(this.itAbrir_Click);
            // 
            // itGuardar
            // 
            this.itGuardar.Image = global::_06Editor.Properties.Resources.guardar;
            this.itGuardar.Name = "itGuardar";
            this.itGuardar.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.itGuardar.Size = new System.Drawing.Size(216, 26);
            this.itGuardar.Text = "&Guardar";
            this.itGuardar.Click += new System.EventHandler(this.itGuardar_Click);
            // 
            // itGuardarComo
            // 
            this.itGuardarComo.Name = "itGuardarComo";
            this.itGuardarComo.Size = new System.Drawing.Size(216, 26);
            this.itGuardarComo.Text = "G&uardar como";
            this.itGuardarComo.Click += new System.EventHandler(this.itGuardarComo_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(213, 6);
            // 
            // itImprimir
            // 
            this.itImprimir.Image = global::_06Editor.Properties.Resources.PrintDocumentControl_697_24;
            this.itImprimir.Name = "itImprimir";
            this.itImprimir.Size = new System.Drawing.Size(216, 26);
            this.itImprimir.Text = "&Imprimir";
            this.itImprimir.Click += new System.EventHandler(this.itImprimir_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(213, 6);
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.salirToolStripMenuItem.Text = "&Salir";
            // 
            // ediciónToolStripMenuItem
            // 
            this.ediciónToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itDeshacer,
            this.itRehacer,
            this.toolStripMenuItem3,
            this.itCortar,
            this.itPegar,
            this.itCopiar,
            this.toolStripMenuItem4,
            this.itBorrar,
            this.itSeleccionarTodo,
            this.toolStripMenuItem5,
            this.itIrA});
            this.ediciónToolStripMenuItem.Name = "ediciónToolStripMenuItem";
            this.ediciónToolStripMenuItem.Size = new System.Drawing.Size(70, 24);
            this.ediciónToolStripMenuItem.Text = "Edición";
            // 
            // itDeshacer
            // 
            this.itDeshacer.Image = global::_06Editor.Properties.Resources.DESHAZ;
            this.itDeshacer.Name = "itDeshacer";
            this.itDeshacer.Size = new System.Drawing.Size(216, 26);
            this.itDeshacer.Text = "Deshacer";
            this.itDeshacer.Click += new System.EventHandler(this.itDeshacer_Click);
            // 
            // itRehacer
            // 
            this.itRehacer.Image = global::_06Editor.Properties.Resources.rehacer;
            this.itRehacer.Name = "itRehacer";
            this.itRehacer.Size = new System.Drawing.Size(216, 26);
            this.itRehacer.Text = "Rehacer";
            this.itRehacer.Click += new System.EventHandler(this.itRehacer_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(213, 6);
            // 
            // itCortar
            // 
            this.itCortar.Image = global::_06Editor.Properties.Resources.CORTAR;
            this.itCortar.Name = "itCortar";
            this.itCortar.Size = new System.Drawing.Size(216, 26);
            this.itCortar.Text = "Cortar";
            this.itCortar.Click += new System.EventHandler(this.itCortar_Click);
            // 
            // itPegar
            // 
            this.itPegar.Image = global::_06Editor.Properties.Resources.PEGA;
            this.itPegar.Name = "itPegar";
            this.itPegar.Size = new System.Drawing.Size(216, 26);
            this.itPegar.Text = "Pegar";
            this.itPegar.Click += new System.EventHandler(this.itPegar_Click);
            // 
            // itCopiar
            // 
            this.itCopiar.Image = global::_06Editor.Properties.Resources.COPIA;
            this.itCopiar.Name = "itCopiar";
            this.itCopiar.Size = new System.Drawing.Size(216, 26);
            this.itCopiar.Text = "Copiar";
            this.itCopiar.Click += new System.EventHandler(this.itCopiar_Click);
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(213, 6);
            // 
            // itBorrar
            // 
            this.itBorrar.Name = "itBorrar";
            this.itBorrar.Size = new System.Drawing.Size(216, 26);
            this.itBorrar.Text = "Borrar";
            this.itBorrar.Click += new System.EventHandler(this.itBorrar_Click);
            // 
            // itSeleccionarTodo
            // 
            this.itSeleccionarTodo.Name = "itSeleccionarTodo";
            this.itSeleccionarTodo.Size = new System.Drawing.Size(216, 26);
            this.itSeleccionarTodo.Text = "Seleccionar todo";
            this.itSeleccionarTodo.Click += new System.EventHandler(this.itSeleccionarTodo_Click);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(213, 6);
            // 
            // itIrA
            // 
            this.itIrA.Name = "itIrA";
            this.itIrA.Size = new System.Drawing.Size(216, 26);
            this.itIrA.Text = "Ir a";
            this.itIrA.Click += new System.EventHandler(this.itIrA_Click);
            // 
            // formatoToolStripMenuItem
            // 
            this.formatoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itFuentes,
            this.itColorDeFondo,
            this.toolStripMenuItem6,
            this.itMargenes,
            this.itJustificacion,
            this.toolStripMenuItem7,
            this.itVinyetas,
            this.toolStripMenuItem8,
            this.itFormatoPagina,
            this.toolStripMenuItem9,
            this.quitarFormatosToolStripMenuItem});
            this.formatoToolStripMenuItem.Name = "formatoToolStripMenuItem";
            this.formatoToolStripMenuItem.Size = new System.Drawing.Size(77, 24);
            this.formatoToolStripMenuItem.Text = "Formato";
            // 
            // itFuentes
            // 
            this.itFuentes.Name = "itFuentes";
            this.itFuentes.Size = new System.Drawing.Size(216, 26);
            this.itFuentes.Text = "F&uentes";
            this.itFuentes.Click += new System.EventHandler(this.itFuentes_Click);
            // 
            // itColorDeFondo
            // 
            this.itColorDeFondo.Name = "itColorDeFondo";
            this.itColorDeFondo.Size = new System.Drawing.Size(216, 26);
            this.itColorDeFondo.Text = "&Color de Fondo";
            this.itColorDeFondo.Click += new System.EventHandler(this.itColorDeFondo_Click);
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(213, 6);
            // 
            // itMargenes
            // 
            this.itMargenes.Name = "itMargenes";
            this.itMargenes.Size = new System.Drawing.Size(216, 26);
            this.itMargenes.Text = "&Márgenes";
            this.itMargenes.Click += new System.EventHandler(this.itMargenes_Click);
            // 
            // itJustificacion
            // 
            this.itJustificacion.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itDerecha,
            this.itCentro,
            this.itIzquierda});
            this.itJustificacion.Name = "itJustificacion";
            this.itJustificacion.Size = new System.Drawing.Size(216, 26);
            this.itJustificacion.Text = "&Justificación";
            // 
            // itDerecha
            // 
            this.itDerecha.Image = global::_06Editor.Properties.Resources.DCHA;
            this.itDerecha.Name = "itDerecha";
            this.itDerecha.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.itDerecha.Size = new System.Drawing.Size(216, 26);
            this.itDerecha.Text = "Derecha";
            this.itDerecha.Click += new System.EventHandler(this.tsbDerecha_Click);
            // 
            // itCentro
            // 
            this.itCentro.Image = global::_06Editor.Properties.Resources.CENTRO;
            this.itCentro.Name = "itCentro";
            this.itCentro.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.E)));
            this.itCentro.Size = new System.Drawing.Size(216, 26);
            this.itCentro.Text = "Centro";
            this.itCentro.Click += new System.EventHandler(this.tsbCentro_Click);
            // 
            // itIzquierda
            // 
            this.itIzquierda.Image = global::_06Editor.Properties.Resources.IZQDA;
            this.itIzquierda.Name = "itIzquierda";
            this.itIzquierda.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.L)));
            this.itIzquierda.Size = new System.Drawing.Size(216, 26);
            this.itIzquierda.Text = "Izquierda";
            this.itIzquierda.Click += new System.EventHandler(this.tsbIzquierda_Click);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(213, 6);
            // 
            // itVinyetas
            // 
            this.itVinyetas.Name = "itVinyetas";
            this.itVinyetas.Size = new System.Drawing.Size(216, 26);
            this.itVinyetas.Text = "&Viñetas";
            this.itVinyetas.Click += new System.EventHandler(this.itVinyetas_Click);
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(213, 6);
            // 
            // itFormatoPagina
            // 
            this.itFormatoPagina.Name = "itFormatoPagina";
            this.itFormatoPagina.Size = new System.Drawing.Size(216, 26);
            this.itFormatoPagina.Text = "F&ormato de Página";
            this.itFormatoPagina.Click += new System.EventHandler(this.itFormatoPagina_Click);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(213, 6);
            // 
            // quitarFormatosToolStripMenuItem
            // 
            this.quitarFormatosToolStripMenuItem.Image = global::_06Editor.Properties.Resources.ESTILO;
            this.quitarFormatosToolStripMenuItem.Name = "quitarFormatosToolStripMenuItem";
            this.quitarFormatosToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.quitarFormatosToolStripMenuItem.Text = "Quitar Formatos";
            // 
            // verToolStripMenuItem
            // 
            this.verToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.itBarraDeHerramientasEstándar,
            this.itBarraDeHerramientasFormato,
            this.itBarraDeEstado});
            this.verToolStripMenuItem.Name = "verToolStripMenuItem";
            this.verToolStripMenuItem.Size = new System.Drawing.Size(42, 24);
            this.verToolStripMenuItem.Text = "Ver";
            // 
            // itBarraDeHerramientasEstándar
            // 
            this.itBarraDeHerramientasEstándar.Checked = true;
            this.itBarraDeHerramientasEstándar.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itBarraDeHerramientasEstándar.Name = "itBarraDeHerramientasEstándar";
            this.itBarraDeHerramientasEstándar.Size = new System.Drawing.Size(294, 26);
            this.itBarraDeHerramientasEstándar.Text = "Barra de Herramientas &estándar";
            this.itBarraDeHerramientasEstándar.Click += new System.EventHandler(this.itBarraDeHerramientasEstándar_Click);
            // 
            // itBarraDeHerramientasFormato
            // 
            this.itBarraDeHerramientasFormato.Checked = true;
            this.itBarraDeHerramientasFormato.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itBarraDeHerramientasFormato.Name = "itBarraDeHerramientasFormato";
            this.itBarraDeHerramientasFormato.Size = new System.Drawing.Size(294, 26);
            this.itBarraDeHerramientasFormato.Text = "Barra de Herramientas &Formato";
            this.itBarraDeHerramientasFormato.Click += new System.EventHandler(this.itBarraDeHerramientasFormato_Click);
            // 
            // itBarraDeEstado
            // 
            this.itBarraDeEstado.Checked = true;
            this.itBarraDeEstado.CheckState = System.Windows.Forms.CheckState.Checked;
            this.itBarraDeEstado.Name = "itBarraDeEstado";
            this.itBarraDeEstado.Size = new System.Drawing.Size(294, 26);
            this.itBarraDeEstado.Text = "Barra de E&stado";
            this.itBarraDeEstado.Click += new System.EventHandler(this.itBarraDeEstado_Click);
            // 
            // ayudaToolStripMenuItem
            // 
            this.ayudaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmAcercaDe,
            this.indiceAyudaToolStripMenuItem,
            this.ayudaGeneralToolStripMenuItem});
            this.ayudaToolStripMenuItem.Name = "ayudaToolStripMenuItem";
            this.ayudaToolStripMenuItem.Size = new System.Drawing.Size(63, 24);
            this.ayudaToolStripMenuItem.Text = "Ayuda";
            // 
            // tsmAcercaDe
            // 
            this.tsmAcercaDe.Name = "tsmAcercaDe";
            this.tsmAcercaDe.Size = new System.Drawing.Size(216, 26);
            this.tsmAcercaDe.Text = "&Acerca de";
            this.tsmAcercaDe.Click += new System.EventHandler(this.tsmAcercaDe_Click);
            // 
            // indiceAyudaToolStripMenuItem
            // 
            this.indiceAyudaToolStripMenuItem.Name = "indiceAyudaToolStripMenuItem";
            this.indiceAyudaToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.indiceAyudaToolStripMenuItem.Text = "&Indice Ayuda";
            // 
            // ayudaGeneralToolStripMenuItem
            // 
            this.ayudaGeneralToolStripMenuItem.Name = "ayudaGeneralToolStripMenuItem";
            this.ayudaGeneralToolStripMenuItem.Size = new System.Drawing.Size(216, 26);
            this.ayudaGeneralToolStripMenuItem.Text = "Ay&uda General";
            // 
            // rtbEditor
            // 
            this.rtbEditor.ContextMenuStrip = this.cmnEdicion;
            this.rtbEditor.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbEditor.Location = new System.Drawing.Point(0, 83);
            this.rtbEditor.Name = "rtbEditor";
            this.rtbEditor.Size = new System.Drawing.Size(1073, 471);
            this.rtbEditor.TabIndex = 4;
            this.rtbEditor.Text = "";
            this.rtbEditor.SelectionChanged += new System.EventHandler(this.rtbEditor_SelectionChanged);
            this.rtbEditor.MouseDown += new System.Windows.Forms.MouseEventHandler(this.rtbEditor_MouseDown);
            // 
            // cmnEdicion
            // 
            this.cmnEdicion.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.cmnEdicion.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deshacerToolStripMenuItem,
            this.rehacerToolStripMenuItem,
            this.toolStripMenuItem10,
            this.cortarToolStripMenuItem,
            this.copiarToolStripMenuItem,
            this.pegarToolStripMenuItem,
            this.toolStripMenuItem11,
            this.suprimirToolStripMenuItem,
            this.toolStripMenuItem12,
            this.seleccionarTodoToolStripMenuItem});
            this.cmnEdicion.Name = "cmnEdicion";
            this.cmnEdicion.Size = new System.Drawing.Size(193, 190);
            // 
            // deshacerToolStripMenuItem
            // 
            this.deshacerToolStripMenuItem.Name = "deshacerToolStripMenuItem";
            this.deshacerToolStripMenuItem.Size = new System.Drawing.Size(192, 24);
            this.deshacerToolStripMenuItem.Text = "Deshacer";
            // 
            // rehacerToolStripMenuItem
            // 
            this.rehacerToolStripMenuItem.Name = "rehacerToolStripMenuItem";
            this.rehacerToolStripMenuItem.Size = new System.Drawing.Size(192, 24);
            this.rehacerToolStripMenuItem.Text = "Rehacer";
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(189, 6);
            // 
            // cortarToolStripMenuItem
            // 
            this.cortarToolStripMenuItem.Name = "cortarToolStripMenuItem";
            this.cortarToolStripMenuItem.Size = new System.Drawing.Size(192, 24);
            this.cortarToolStripMenuItem.Text = "Cortar";
            // 
            // copiarToolStripMenuItem
            // 
            this.copiarToolStripMenuItem.Name = "copiarToolStripMenuItem";
            this.copiarToolStripMenuItem.Size = new System.Drawing.Size(192, 24);
            this.copiarToolStripMenuItem.Text = "Copiar";
            // 
            // pegarToolStripMenuItem
            // 
            this.pegarToolStripMenuItem.Name = "pegarToolStripMenuItem";
            this.pegarToolStripMenuItem.Size = new System.Drawing.Size(192, 24);
            this.pegarToolStripMenuItem.Text = "Pegar";
            // 
            // toolStripMenuItem11
            // 
            this.toolStripMenuItem11.Name = "toolStripMenuItem11";
            this.toolStripMenuItem11.Size = new System.Drawing.Size(189, 6);
            // 
            // suprimirToolStripMenuItem
            // 
            this.suprimirToolStripMenuItem.Name = "suprimirToolStripMenuItem";
            this.suprimirToolStripMenuItem.Size = new System.Drawing.Size(192, 24);
            this.suprimirToolStripMenuItem.Text = "Suprimir";
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(189, 6);
            // 
            // seleccionarTodoToolStripMenuItem
            // 
            this.seleccionarTodoToolStripMenuItem.Name = "seleccionarTodoToolStripMenuItem";
            this.seleccionarTodoToolStripMenuItem.Size = new System.Drawing.Size(192, 24);
            this.seleccionarTodoToolStripMenuItem.Text = "Seleccionar Todo";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timeEditor_Tick);
            // 
            // dlgAbrir
            // 
            this.dlgAbrir.AutoUpgradeEnabled = false;
            this.dlgAbrir.DefaultExt = "rtf";
            this.dlgAbrir.Filter = "Archivo de Texto(.txt)|*.txt|Archivo Rico(.rtf)|*.rtf|Todos los archivos(*.*)|*.*" +
    "";
            this.dlgAbrir.InitialDirectory = ".\\";
            // 
            // dlgGuardar
            // 
            this.dlgGuardar.AutoUpgradeEnabled = false;
            this.dlgGuardar.DefaultExt = "rtf";
            this.dlgGuardar.Filter = "Archivo de Texto(.txt)|*.txt|Archivo Rico(.rtf)|*.rtf|Todos los archivos(*.*)|*.*" +
    "";
            this.dlgGuardar.FilterIndex = 2;
            this.dlgGuardar.InitialDirectory = ".\\";
            this.dlgGuardar.Title = "Guardando como";
            // 
            // dlgImprimir
            // 
            this.dlgImprimir.AllowSomePages = true;
            this.dlgImprimir.Document = this.printDocEditor;
            this.dlgImprimir.PrintToFile = true;
            this.dlgImprimir.ShowHelp = true;
            this.dlgImprimir.UseEXDialog = true;
            // 
            // printDocEditor
            // 
            this.printDocEditor.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocEditor_PrintPage);
            // 
            // dlgColor
            // 
            this.dlgColor.AnyColor = true;
            // 
            // dlgFuente
            // 
            this.dlgFuente.ShowColor = true;
            // 
            // fmEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1073, 578);
            this.Controls.Add(this.rtbEditor);
            this.Controls.Add(this.stEstadoEditor);
            this.Controls.Add(this.tsBarraFormato);
            this.Controls.Add(this.tsBarraEstandar);
            this.Controls.Add(this.mnsEditor);
            this.MainMenuStrip = this.mnsEditor;
            this.Name = "fmEditor";
            this.Text = "Documento1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.fmEditor_FormClosing);
            this.Load += new System.EventHandler(this.fmEditor_Load);
            this.Resize += new System.EventHandler(this.fmEditor_Resize);
            this.tsBarraEstandar.ResumeLayout(false);
            this.tsBarraEstandar.PerformLayout();
            this.cmnBarras.ResumeLayout(false);
            this.tsBarraFormato.ResumeLayout(false);
            this.tsBarraFormato.PerformLayout();
            this.stEstadoEditor.ResumeLayout(false);
            this.stEstadoEditor.PerformLayout();
            this.mnsEditor.ResumeLayout(false);
            this.mnsEditor.PerformLayout();
            this.cmnEdicion.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip tsBarraEstandar;
        private System.Windows.Forms.ToolStripButton tsbNuevo;
        private System.Windows.Forms.ToolStripButton tsbAbrir;
        private System.Windows.Forms.ToolStripButton tsbGuardar;
        private System.Windows.Forms.ToolStripButton tsbImprimir;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsbCortar;
        private System.Windows.Forms.ToolStripButton tsbCopiar;
        private System.Windows.Forms.ToolStripButton tsbPegar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton tsbDeshacer;
        private System.Windows.Forms.ToolStripButton tsbRehacer;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton tsbCopiarFormato;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton itQuitarFormato;
        private System.Windows.Forms.ToolStrip tsBarraFormato;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton tsbNegrita;
        private System.Windows.Forms.ToolStripButton tsbCursiva;
        private System.Windows.Forms.ToolStripButton tsbSubrayado;
        private System.Windows.Forms.ToolStripButton tsbTachado;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton tsbIzquierda;
        private System.Windows.Forms.ToolStripButton tsbCentro;
        private System.Windows.Forms.ToolStripButton tsbDerecha;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripComboBox cbFuentes;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripComboBox cbTamanyo;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripButton tsbColores;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.StatusStrip stEstadoEditor;
        private System.Windows.Forms.ToolStripStatusLabel sl1;
        private System.Windows.Forms.ToolStripStatusLabel sl2;
        private System.Windows.Forms.ToolStripStatusLabel sl3;
        private System.Windows.Forms.ToolStripStatusLabel sl4;
        private System.Windows.Forms.ToolStripStatusLabel sl5;
        private System.Windows.Forms.MenuStrip mnsEditor;
        private System.Windows.Forms.ToolStripMenuItem archivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ediciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formatoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ayudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itNuevo;
        private System.Windows.Forms.ToolStripMenuItem itAbrir;
        private System.Windows.Forms.ToolStripMenuItem itGuardar;
        private System.Windows.Forms.ToolStripMenuItem itGuardarComo;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem itImprimir;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itDeshacer;
        private System.Windows.Forms.ToolStripMenuItem itRehacer;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem itCortar;
        private System.Windows.Forms.ToolStripMenuItem itPegar;
        private System.Windows.Forms.ToolStripMenuItem itCopiar;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem itBorrar;
        private System.Windows.Forms.ToolStripMenuItem itSeleccionarTodo;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem itIrA;
        private System.Windows.Forms.ToolStripMenuItem itFuentes;
        private System.Windows.Forms.ToolStripMenuItem itColorDeFondo;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem itMargenes;
        private System.Windows.Forms.ToolStripMenuItem itJustificacion;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem itVinyetas;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem itFormatoPagina;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem quitarFormatosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itBarraDeHerramientasEstándar;
        private System.Windows.Forms.ToolStripMenuItem itBarraDeHerramientasFormato;
        private System.Windows.Forms.ToolStripMenuItem itBarraDeEstado;
        private System.Windows.Forms.ToolStripMenuItem tsmAcercaDe;
        private System.Windows.Forms.ToolStripMenuItem indiceAyudaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ayudaGeneralToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.OpenFileDialog dlgAbrir;
        private System.Windows.Forms.SaveFileDialog dlgGuardar;
        private System.Windows.Forms.PrintDialog dlgImprimir;
        private System.Drawing.Printing.PrintDocument printDocEditor;
        public System.Windows.Forms.RichTextBox rtbEditor;
        private System.Windows.Forms.ColorDialog dlgColor;
        private System.Windows.Forms.ContextMenuStrip cmnBarras;
        private System.Windows.Forms.ToolStripMenuItem tsmBarraHerramEstandar;
        private System.Windows.Forms.ToolStripMenuItem tsmBarraDeHerramFormato;
        private System.Windows.Forms.ToolStripMenuItem tsmBarraDeEstado;
        private System.Windows.Forms.ToolStripMenuItem itDerecha;
        private System.Windows.Forms.ToolStripMenuItem itCentro;
        private System.Windows.Forms.ToolStripMenuItem itIzquierda;
        private System.Windows.Forms.FontDialog dlgFuente;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ContextMenuStrip cmnEdicion;
        private System.Windows.Forms.ToolStripMenuItem deshacerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rehacerToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem cortarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copiarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pegarToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem11;
        private System.Windows.Forms.ToolStripMenuItem suprimirToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem seleccionarTodoToolStripMenuItem;
    }
}

